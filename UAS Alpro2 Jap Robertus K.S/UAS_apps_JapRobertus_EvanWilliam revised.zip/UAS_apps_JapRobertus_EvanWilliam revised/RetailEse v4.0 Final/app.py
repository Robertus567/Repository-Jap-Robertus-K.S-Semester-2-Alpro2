from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import mysql.connector
import google.generativeai as genai
import json
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Ganti dengan secret key yang aman

# Konfigurasi database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',  # Sesuaikan dengan username database Anda
    'password': '',  # Sesuaikan dengan password database Anda
    'database': 'retailese_db'  # Sesuaikan dengan nama database Anda
}

def get_db_connection():
    """Membuat koneksi ke database"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except mysql.connector.Error as err:
        print(f"Database Connection Error: {err}")
        return None

def get_sales_data():
    """Mengambil data penjualan dari database"""
    conn = get_db_connection()
    if not conn:
        return []
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        query = """
        SELECT 
            id,
            nama_barang,
            harga_satuan,
            jumlah,
            total_harga,
            tanggal_penjualan,
            created_at
        FROM penjualan 
        ORDER BY tanggal_penjualan DESC, created_at DESC
        LIMIT 100
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        
        # Convert datetime objects to strings for JSON serialization
        for result in results:
            for key, value in result.items():
                if isinstance(value, datetime):
                    result[key] = value.strftime('%Y-%m-%d %H:%M:%S')
                elif hasattr(value, 'date'):  # Handle date objects
                    result[key] = value.strftime('%Y-%m-%d')
        
        return results
        
    except mysql.connector.Error as err:
        print(f"Sales Data Error: {err}")
        return []
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

def get_stock_data():
    """Mengambil data stok barang"""
    conn = get_db_connection()
    if not conn:
        return []
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        query = """
        SELECT 
            id,
            nama,
            harga,
            jumlah,
            tanggal_kadaluarsa,
            tanggal_masuk,
            created_at
        FROM stok_barang 
        ORDER BY nama
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        
        # Convert datetime objects to strings
        for result in results:
            for key, value in result.items():
                if isinstance(value, datetime):
                    result[key] = value.strftime('%Y-%m-%d %H:%M:%S')
                elif hasattr(value, 'date'):  # Handle date objects
                    result[key] = value.strftime('%Y-%m-%d')
        
        return results
        
    except mysql.connector.Error as err:
        print(f"Stock Data Error: {err}")
        return []
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

def get_kulakan_data():
    """Mengambil data kulakan dari database"""
    conn = get_db_connection()
    if not conn:
        return []
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        query = """
        SELECT 
            id,
            nama_toko,
            nama_barang,
            harga,
            tanggal,
            catatan,
            created_at
        FROM kulakan 
        ORDER BY tanggal DESC
        LIMIT 50
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        
        # Convert datetime objects to strings
        for result in results:
            for key, value in result.items():
                if isinstance(value, datetime):
                    result[key] = value.strftime('%Y-%m-%d %H:%M:%S')
                elif hasattr(value, 'date'):  # Handle date objects
                    result[key] = value.strftime('%Y-%m-%d')
        
        return results
        
    except mysql.connector.Error as err:
        print(f"Kulakan Data Error: {err}")
        return []
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

def prepare_context_for_ai():
    """Menyiapkan konteks data untuk AI"""
    try:
        sales_data = get_sales_data()
        stock_data = get_stock_data()
        kulakan_data = get_kulakan_data()
        
        # Analisis data untuk memberikan insights
        total_sales = len(sales_data)
        low_stock_items = []
        expired_soon = []
        
        # Analisis stok menipis
        for item in stock_data:
            try:
                if item['jumlah'] is not None and int(item['jumlah']) <= 5:
                    low_stock_items.append(item)
            except (ValueError, TypeError):
                continue
        
        # Cek barang yang akan kadaluarsa dalam 7 hari
        today = datetime.now().date()
        week_later = today + timedelta(days=7)
        
        for item in stock_data:
            try:
                if item['tanggal_kadaluarsa']:
                    # Parse tanggal kadaluarsa
                    if isinstance(item['tanggal_kadaluarsa'], str):
                        exp_date = datetime.strptime(item['tanggal_kadaluarsa'], '%Y-%m-%d').date()
                    else:
                        exp_date = item['tanggal_kadaluarsa']
                    
                    if exp_date <= week_later:
                        expired_soon.append(item)
            except (ValueError, TypeError) as e:
                print(f"Date parsing error for item {item.get('nama', 'unknown')}: {e}")
                continue
        
        context = {
            "data_penjualan": sales_data[:20],
            "data_stok": stock_data,
            "data_kulakan": kulakan_data[:20],
            "analisis": {
                "total_penjualan": total_sales,
                "barang_stok_menipis": low_stock_items,
                "barang_akan_kadaluarsa": expired_soon,
                "total_jenis_barang": len(stock_data)
            },
            "tanggal_sekarang": datetime.now().strftime("%Y-%m-%d")
        }
        
        return context
        
    except Exception as e:
        print(f"Context preparation error: {e}")
        return {
            "data_penjualan": [],
            "data_stok": [],
            "data_kulakan": [],
            "analisis": {
                "total_penjualan": 0,
                "barang_stok_menipis": [],
                "barang_akan_kadaluarsa": [],
                "total_jenis_barang": 0
            },
            "tanggal_sekarang": datetime.now().strftime("%Y-%m-%d")
        }

@app.route('/')
def index():
    """Halaman login API key"""
    if 'api_key' in session:
        return redirect(url_for('chat'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    """Proses login dengan API key"""
    api_key = request.form.get('api_key')
    
    if not api_key:
        return render_template('login.html', error='API Key tidak boleh kosong')
    
    # Test API key dengan Gemini
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Test sederhana
        test_response = model.generate_content("Hello")
        
        # Jika berhasil, simpan di session
        session['api_key'] = api_key
        return redirect(url_for('chat'))
        
    except Exception as e:
        error_msg = str(e)
        print(f"API Key Error: {error_msg}")
        
        if "API_KEY_INVALID" in error_msg or "invalid" in error_msg.lower():
            error_display = "API Key tidak valid. Pastikan Anda menggunakan API Key yang benar dari Google AI Studio."
        elif "quota" in error_msg.lower() or "limit" in error_msg.lower():
            error_display = "Quota API habis atau limit tercapai. Cek usage di Google AI Studio."
        elif "permission" in error_msg.lower() or "denied" in error_msg.lower():
            error_display = "API Key tidak memiliki permission. Pastikan Gemini API sudah diaktifkan."
        elif "billing" in error_msg.lower():
            error_display = "Masalah billing. Periksa pengaturan pembayaran di Google Cloud Console."
        else:
            error_display = f"Error koneksi API: {error_msg[:100]}..."
            
        return render_template('login.html', error=error_display)

@app.route('/chat')
def chat():
    """Halaman chat utama"""
    if 'api_key' not in session:
        return redirect(url_for('index'))
    return render_template('chat.html')

@app.route('/api/chat', methods=['POST'])
def chat_api():
    """API endpoint untuk chat"""
    if 'api_key' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Data tidak valid'}), 400
            
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'Pesan tidak boleh kosong'}), 400
        
        print(f"User message: {user_message}")  # Debug log
        
        # Konfigurasi Gemini AI
        genai.configure(api_key=session['api_key'])
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Siapkan konteks data
        context = prepare_context_for_ai()
        print(f"Context prepared - Sales: {len(context['data_penjualan'])}, Stock: {len(context['data_stok'])}")  # Debug
        
        # Format prompt yang lebih sederhana dan robust
        prompt = f"""
Anda adalah asisten chatbot untuk toko retail. Berikan jawaban dalam bahasa Indonesia yang praktis dan mudah dipahami.

INFORMASI TOKO SAAT INI:
- Total transaksi penjualan: {context['analisis']['total_penjualan']}
- Total jenis barang di stok: {context['analisis']['total_jenis_barang']}
- Barang stok menipis (≤5): {len(context['analisis']['barang_stok_menipis'])} item
- Barang akan kadaluarsa (≤7 hari): {len(context['analisis']['barang_akan_kadaluarsa'])} item

BARANG STOK MENIPIS:
{[item['nama'] + ' (sisa: ' + str(item['jumlah']) + ')' for item in context['analisis']['barang_stok_menipis'][:5]]}

BARANG AKAN KADALUARSA:
{[item['nama'] + ' (exp: ' + str(item['tanggal_kadaluarsa']) + ')' for item in context['analisis']['barang_akan_kadaluarsa'][:5]]}

Pertanyaan pengguna: {user_message}

Berikan jawaban yang membantu dan berbasis data yang tersedia. Jika tidak ada data yang relevan, berikan saran umum untuk bisnis retail.
"""
        
        print("Sending to Gemini...")  # Debug log
        
        # Generate response dengan error handling
        response = model.generate_content(prompt)
        
        if response and response.text:
            bot_response = response.text
            print(f"Gemini response received: {len(bot_response)} characters")  # Debug
        else:
            bot_response = "Maaf, saya tidak dapat memproses permintaan Anda saat ini. Silakan coba lagi."
        
        return jsonify({
            'response': bot_response,
            'timestamp': datetime.now().strftime("%H:%M:%S")
        })
        
    except Exception as e:
        error_msg = str(e)
        print(f"Chat API Error: {error_msg}")
        
        # Return specific error messages
        if "quota" in error_msg.lower() or "limit" in error_msg.lower():
            return jsonify({'error': 'Quota API Gemini habis. Silakan cek Google AI Studio.'}), 500
        elif "api_key" in error_msg.lower() or "invalid" in error_msg.lower():
            return jsonify({'error': 'API Key tidak valid. Silakan login ulang.'}), 500
        else:
            return jsonify({'error': f'Terjadi kesalahan: {error_msg[:100]}...'}), 500

@app.route('/api/dashboard')
def dashboard_api():
    """API untuk data dashboard"""
    if 'api_key' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        print("Loading dashboard data...")  # Debug log
        context = prepare_context_for_ai()
        
        dashboard_data = {
            'total_penjualan': context['analisis']['total_penjualan'],
            'total_barang': context['analisis']['total_jenis_barang'],
            'stok_menipis': len(context['analisis']['barang_stok_menipis']),
            'akan_kadaluarsa': len(context['analisis']['barang_akan_kadaluarsa']),
            'barang_stok_menipis': context['analisis']['barang_stok_menipis'][:5],
            'barang_akan_kadaluarsa': context['analisis']['barang_akan_kadaluarsa'][:5]
        }
        
        print(f"Dashboard data: {dashboard_data}")  # Debug log
        return jsonify(dashboard_data)
        
    except Exception as e:
        print(f"Dashboard API Error: {e}")
        return jsonify({
            'total_penjualan': 0,
            'total_barang': 0,
            'stok_menipis': 0,
            'akan_kadaluarsa': 0,
            'barang_stok_menipis': [],
            'barang_akan_kadaluarsa': []
        }), 200  # Return empty data instead of error

@app.route('/logout')
def logout():
    """Logout dan hapus session"""
    session.clear()
    return redirect(url_for('index'))

@app.route('/debug/data')
def debug_data():
    """Debug endpoint untuk melihat data"""
    if 'api_key' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        context = prepare_context_for_ai()
        return jsonify({
            'sales_count': len(context['data_penjualan']),
            'stock_count': len(context['data_stok']),
            'kulakan_count': len(context['data_kulakan']),
            'sample_stock': context['data_stok'][:3] if context['data_stok'] else [],
            'low_stock': context['analisis']['barang_stok_menipis'][:3],
            'expiring': context['analisis']['barang_akan_kadaluarsa'][:3]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)