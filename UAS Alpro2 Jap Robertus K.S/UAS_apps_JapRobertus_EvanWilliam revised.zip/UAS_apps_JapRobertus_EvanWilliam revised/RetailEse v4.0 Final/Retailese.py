import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import csv
import os
import sys
from datetime import datetime, date
import heapq  # Untuk algoritma optimasi pencarian (priority queue)
import mysql.connector
from mysql.connector import Error

class DatabaseConfigDialog:
    def __init__(self, parent):
        self.result = None
        self.parent = parent
        
        # Hide main window PROPERLY
        self.parent.withdraw()
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Konfigurasi Database MySQL")
        self.dialog.geometry("450x400")
        self.dialog.grab_set()
        self.dialog.resizable(False, False)
        
        # Center the dialog
        self.center_window()
        
        self.setup_ui()
        
        # Handle window close
        self.dialog.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def center_window(self):
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (450 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (400 // 2)
        self.dialog.geometry(f"450x400+{x}+{y}")
        
    def setup_ui(self):
        main_frame = ttk.Frame(self.dialog, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(main_frame, text="Konfigurasi Database MySQL", 
                 font=("Arial", 16, "bold")).pack(pady=(0, 20))
        
        ttk.Label(main_frame, text="Masukkan detail koneksi database Anda:", 
                 font=("Arial", 10)).pack(pady=(0, 15))
        
        # Form frame untuk input fields
        form_frame = ttk.Frame(main_frame)
        form_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Host
        host_frame = ttk.Frame(form_frame)
        host_frame.pack(fill=tk.X, pady=5)
        ttk.Label(host_frame, text="Host:", width=12, anchor="w").pack(side=tk.LEFT)
        self.host_var = tk.StringVar(value="localhost")
        host_entry = ttk.Entry(host_frame, textvariable=self.host_var, font=("Arial", 10))
        host_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5,0))
        
        # User
        user_frame = ttk.Frame(form_frame)
        user_frame.pack(fill=tk.X, pady=5)
        ttk.Label(user_frame, text="Username:", width=12, anchor="w").pack(side=tk.LEFT)
        self.user_var = tk.StringVar(value="root")
        user_entry = ttk.Entry(user_frame, textvariable=self.user_var, font=("Arial", 10))
        user_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5,0))
        
        # Password
        pass_frame = ttk.Frame(form_frame)
        pass_frame.pack(fill=tk.X, pady=5)
        ttk.Label(pass_frame, text="Password:", width=12, anchor="w").pack(side=tk.LEFT)
        self.pass_var = tk.StringVar()
        pass_entry = ttk.Entry(pass_frame, textvariable=self.pass_var, show="*", font=("Arial", 10))
        pass_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5,0))
        
        # Database
        db_frame = ttk.Frame(form_frame)
        db_frame.pack(fill=tk.X, pady=5)
        ttk.Label(db_frame, text="Database:", width=12, anchor="w").pack(side=tk.LEFT)
        self.db_var = tk.StringVar(value="retailese_db")
        db_entry = ttk.Entry(db_frame, textvariable=self.db_var, font=("Arial", 10))
        db_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5,0))
        
        # Status label
        self.status_label = ttk.Label(main_frame, text="Klik 'Test Koneksi' untuk memverifikasi", 
                                     foreground="blue", font=("Arial", 9))
        self.status_label.pack(pady=(10, 20))
        
        # Button frame - PERBAIKAN UTAMA DI SINI
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Test button
        self.test_btn = ttk.Button(
            button_frame, 
            text="Test Koneksi", 
            command=self.test_connection,
            width=15
        )
        self.test_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # Connect button (disabled initially)
        self.connect_btn = ttk.Button(
            button_frame, 
            text="Mulai Aplikasi", 
            command=self.save_config,
            width=15,
            state="disabled"
        )
        self.connect_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # Info label
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=(10, 0))
        info_label = ttk.Label(
            info_frame, 
            text="Pastikan MySQL server sudah berjalan sebelum test koneksi",
            font=("Arial", 8),
            foreground="gray"
        )
        info_label.pack()
        
    def test_connection(self):
        """Test koneksi database"""
        self.status_label.config(text="Mengetes koneksi...", foreground="orange")
        self.test_btn.config(state="disabled")
        self.dialog.update()
        
        try:
            # Validasi input terlebih dahulu
            if not self.host_var.get().strip():
                raise ValueError("Host tidak boleh kosong")
            if not self.user_var.get().strip():
                raise ValueError("Username tidak boleh kosong")
            if not self.db_var.get().strip():
                raise ValueError("Nama database tidak boleh kosong")
            
            config = {
                'host': self.host_var.get().strip(),
                'user': self.user_var.get().strip(),
                'password': self.pass_var.get()
            }
            
            # Test connection without database first
            connection = mysql.connector.connect(**config)
            cursor = connection.cursor()
            
            # Create database if not exists
            db_name = self.db_var.get().strip()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
            cursor.close()
            connection.close()
            
            # Test connection with database
            config['database'] = db_name
            connection = mysql.connector.connect(**config)
            connection.close()
            
            self.status_label.config(
                text="✓ Koneksi berhasil! Silakan klik 'Mulai Aplikasi'", 
                foreground="green"
            )
            self.connect_btn.config(state="normal")
            
        except Error as e:
            error_msg = str(e)
            if "Access denied" in error_msg:
                error_msg = "Username atau password salah"
            elif "Can't connect" in error_msg:
                error_msg = "Tidak dapat terhubung ke MySQL server"
            
            self.status_label.config(
                text=f"✗ Koneksi gagal: {error_msg}", 
                foreground="red"
            )
            self.connect_btn.config(state="disabled")
            
        except ValueError as e:
            self.status_label.config(
                text=f"✗ Error: {str(e)}", 
                foreground="red"
            )
            self.connect_btn.config(state="disabled")
            
        except Exception as e:
            self.status_label.config(
                text=f"✗ Error tidak terduga: {str(e)}", 
                foreground="red"
            )
            self.connect_btn.config(state="disabled")
            
        finally:
            self.test_btn.config(state="normal")
    
    def save_config(self):
        """Simpan konfigurasi dan tutup dialog"""
        self.result = {
            'host': self.host_var.get().strip(),
            'user': self.user_var.get().strip(),
            'password': self.pass_var.get(),
            'database': self.db_var.get().strip()
        }
        # Show main window kembali
        self.parent.deiconify()
        self.dialog.destroy()
    
    def on_closing(self):
        """Handle window close button"""
        self.result = None
        # Show main window kembali meski user cancel
        self.parent.deiconify()
        self.dialog.destroy()

class Retailese:
    def __init__(self, root):
        """Inisialisasi aplikasi Retailese"""
        self.root = root
        self.root.title("Retailese - Sistem Manajemen Gudang")
        self.root.geometry("950x650")
        self.root.configure(bg="#f0f0f0")
        
        # Definisi kolom untuk database
        self.columns = ["Nama", "Harga", "Jumlah", "Tanggal Kadaluarsa", "Tanggal Masuk"]
        
        # Konfigurasi database akan diisi setelah dialog
        self.db_config = None
        
        # Tampilkan dialog konfigurasi database DULU
        if not self.setup_database_config():
            self.root.quit()
            return
        
        # BARU tampilkan main window setelah database configured
        self.root.deiconify()  # Show main window
        
        # Inisialisasi database dan tabel
        self.init_database()
        
        # Variabel untuk menyimpan data sementara
        self.filtered_data = []
        self.selected_item_id = None
        
        self.setup_ui()
        self.load_data()

        try:
            self.load_sales_report()
        except:
            pass

    def setup_database_config(self):
        """Setup konfigurasi database melalui dialog"""
        dialog = DatabaseConfigDialog(self.root)
        self.root.wait_window(dialog.dialog)
        
        if dialog.result:
            self.db_config = dialog.result
            return True
        else:
            # Kalau user cancel, tutup aplikasi
            self.root.quit()
            return False
        
    def init_database(self):
        """Inisialisasi database dan tabel MySQL"""
        try:
            # Koneksi tanpa database untuk membuat database
            temp_config = self.db_config.copy()
            temp_config.pop('database')
            
            connection = mysql.connector.connect(**temp_config)
            cursor = connection.cursor()
            
            # Buat database jika belum ada
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {self.db_config['database']}")
            
            cursor.close()
            connection.close()
            
            # Koneksi ke database yang sudah dibuat
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            # Buat tabel stok barang
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stok_barang (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nama VARCHAR(255) NOT NULL,
                    harga DECIMAL(10,2) NOT NULL,
                    jumlah INT NOT NULL,
                    tanggal_kadaluarsa DATE NOT NULL,
                    tanggal_masuk DATE NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Buat tabel kulakan
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS kulakan (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nama_toko VARCHAR(255) NOT NULL,
                    nama_barang VARCHAR(255) NOT NULL,
                    harga DECIMAL(10,2) NOT NULL,
                    tanggal DATE NOT NULL,
                    catatan TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Buat tabel penjualan
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS penjualan (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nama_barang VARCHAR(255) NOT NULL,
                    harga_satuan DECIMAL(10,2) NOT NULL,
                    jumlah INT NOT NULL,
                    total_harga DECIMAL(10,2) NOT NULL,
                    tanggal_penjualan DATE NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            connection.commit()
            cursor.close()
            connection.close()
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal menginisialisasi database: {str(e)}")

    def setup_report_tab(self, parent):
            """Setup tab Laporan Penjualan"""
            # Frame kontrol
            control_frame = ttk.Frame(parent)
            control_frame.pack(fill=tk.X, padx=5, pady=5)
            
            ttk.Button(
                control_frame, 
                text="Muat Laporan", 
                command=self.load_sales_report
            ).pack(side=tk.LEFT, padx=5)
            
            ttk.Button(
                control_frame, 
                text="Ekspor Laporan ke CSV", 
                command=self.export_sales_report
            ).pack(side=tk.RIGHT, padx=5)
            
            # Frame untuk total penjualan
            total_frame = ttk.LabelFrame(parent, text="Ringkasan Penjualan", padding=10)
            total_frame.pack(fill=tk.X, padx=5, pady=5)
            
            self.total_sales_label = ttk.Label(total_frame, text="Total Penjualan: Rp 0", font=("Arial", 12, "bold"))
            self.total_sales_label.pack()
            
            self.total_items_label = ttk.Label(total_frame, text="Total Barang Terjual: 0 unit")
            self.total_items_label.pack()
            
            # Tabel laporan penjualan
            table_frame = ttk.Frame(parent)
            table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            # Scrollbar
            y_scrollbar = ttk.Scrollbar(table_frame)
            y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Treeview untuk laporan
            self.sales_tree = ttk.Treeview(
                table_frame,
                columns=["Nama Barang", "Harga Satuan", "Jumlah", "Total Harga", "Tanggal"],
                show="headings",
                yscrollcommand=y_scrollbar.set
            )
            
            y_scrollbar.config(command=self.sales_tree.yview)
            
            # Setup kolom
            self.sales_tree.heading("Nama Barang", text="Nama Barang")
            self.sales_tree.column("Nama Barang", width=150, anchor=tk.W)
            
            self.sales_tree.heading("Harga Satuan", text="Harga Satuan")
            self.sales_tree.column("Harga Satuan", width=100, anchor=tk.CENTER)
            
            self.sales_tree.heading("Jumlah", text="Jumlah")
            self.sales_tree.column("Jumlah", width=80, anchor=tk.CENTER)
            
            self.sales_tree.heading("Total Harga", text="Total Harga")
            self.sales_tree.column("Total Harga", width=120, anchor=tk.CENTER)
            
            self.sales_tree.heading("Tanggal", text="Tanggal")
            self.sales_tree.column("Tanggal", width=100, anchor=tk.CENTER)
            
            self.sales_tree.pack(fill=tk.BOTH, expand=True)
            
    def setup_ui(self):
        """Membuat antarmuka pengguna (GUI)"""
        # Frame utama
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Judul aplikasi
        title_label = ttk.Label(main_frame, text="RETAILESE", font=("Arial", 24, "bold"))
        title_label.pack(pady=(0, 20))
        subtitle_label = ttk.Label(main_frame, text="Sistem Manajemen Gudang", font=("Arial", 14))
        subtitle_label.pack(pady=(0, 20))
        
        # Tab Control untuk memisahkan fungsi-fungsi
        self.tab_control = ttk.Notebook(main_frame)
        
        # Tab untuk input stok
        input_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(input_tab, text="Input Stok")
        
        # Tab untuk melihat data
        view_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(view_tab, text="Atur & Lihat Stok")
        
        # Tab untuk filter kadaluarsa
        filter_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(filter_tab, text="Filter Kadaluarsa")
        
        # Tab manajemen kulakan
        kulakan_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(kulakan_tab, text="Smart Kulakan")
        

        # Tab laporan penjualan
        report_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(report_tab, text="Laporan Penjualan")
        
        self.tab_control.pack(expand=True, fill=tk.BOTH)
        
        # Setup tiap tab
        self.setup_input_tab(input_tab)
        self.setup_view_tab(view_tab)
        self.setup_filter_tab(filter_tab)
        self.setup_kulakan_tab(kulakan_tab)
        self.setup_report_tab(report_tab)
        
        # Footer
        footer_frame = ttk.Frame(self.root)
        footer_frame.pack(fill=tk.X, pady=10)
        footer_label = ttk.Label(footer_frame, text="© 2025 Retailese - Sistem Manajemen Gudang", font=("Arial", 8))
        footer_label.pack()
    
    def save_item(self):
        """Menyimpan data barang baru ke database MySQL"""
        # Mengambil nilai dari form
        nama = self.nama_var.get().strip()
        harga = self.harga_var.get().strip()
        jumlah = self.jumlah_var.get().strip()
        
        # Validasi input
        if not nama or not harga or not jumlah:
            messagebox.showerror("Error", "Semua field harus diisi!")
            return
        
        try:
            harga = float(harga)
            jumlah = int(jumlah)
            
            if harga <= 0 or jumlah <= 0:
                messagebox.showerror("Error", "Harga dan Jumlah harus lebih dari 0!")
                return
                
        except ValueError:
            messagebox.showerror("Error", "Harga harus berupa angka dan Jumlah harus berupa bilangan bulat!")
            return
        
        # Validasi format tanggal kadaluarsa
        try:
            day = int(self.exp_day_var.get())
            month = int(self.exp_month_var.get())
            year = self.exp_year_var.get()
            
            # Konversi ke format internal YYYY-MM-DD
            exp_date = self.date_to_internal_format(day, month, year)
            
            # Validasi tanggal kadaluarsa
            datetime.strptime(exp_date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Format tanggal kadaluarsa tidak valid! Gunakan format DD-MM-YY")
            return
        
        # Menggunakan tanggal hari ini untuk Tanggal Masuk
        entry_date = datetime.now().strftime("%Y-%m-%d")
        
        try:
            # Simpan ke database MySQL
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = """INSERT INTO stok_barang (nama, harga, jumlah, tanggal_kadaluarsa, tanggal_masuk) 
                    VALUES (%s, %s, %s, %s, %s)"""
            cursor.execute(query, (nama, harga, jumlah, exp_date, entry_date))
            
            connection.commit()
            cursor.close()
            connection.close()
            
            # Reset form dan muat ulang data
            self.reset_form()
            self.load_data()
            messagebox.showinfo("Sukses", f"Barang {nama} berhasil ditambahkan!")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal menyimpan data: {str(e)}")

    def reset_form(self):
        """Membersihkan form input"""
        self.nama_var.set("")
        self.harga_var.set("")
        self.jumlah_var.set("")
        self.exp_day_var.set("")
        self.exp_month_var.set("")
        self.exp_year_var.set("")

    def setup_input_tab(self, parent):
        """Membuat antarmuka tab Input Stok"""
        # Form untuk input stok
        form_frame = ttk.LabelFrame(parent, text="Input Barang Baru", padding=15)
        form_frame.pack(fill=tk.X, padx=5, pady=10)
        
        # Nama Barang
        nama_frame = ttk.Frame(form_frame)
        nama_frame.pack(fill=tk.X, pady=5)
        ttk.Label(nama_frame, text="Nama Barang:", width=15).pack(side=tk.LEFT)
        self.nama_var = tk.StringVar()
        ttk.Entry(nama_frame, textvariable=self.nama_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Harga per unit
        harga_frame = ttk.Frame(form_frame)
        harga_frame.pack(fill=tk.X, pady=5)
        ttk.Label(harga_frame, text="Harga (Rp):", width=15).pack(side=tk.LEFT)
        self.harga_var = tk.StringVar()
        ttk.Entry(harga_frame, textvariable=self.harga_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Jumlah
        jumlah_frame = ttk.Frame(form_frame)
        jumlah_frame.pack(fill=tk.X, pady=5)
        ttk.Label(jumlah_frame, text="Jumlah:", width=15).pack(side=tk.LEFT)
        self.jumlah_var = tk.StringVar()
        ttk.Entry(jumlah_frame, textvariable=self.jumlah_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Tanggal Kadaluarsa
        kadaluarsa_frame = ttk.Frame(form_frame)
        kadaluarsa_frame.pack(fill=tk.X, pady=5)
        ttk.Label(kadaluarsa_frame, text="Tanggal Kadaluarsa:", width=15).pack(side=tk.LEFT)
        
        # Input untuk tanggal kadaluarsa (DD-MM-YY)
        exp_date_frame = ttk.Frame(kadaluarsa_frame)
        exp_date_frame.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.exp_day_var = tk.StringVar()
        self.exp_month_var = tk.StringVar()
        self.exp_year_var = tk.StringVar()
        
        ttk.Entry(exp_date_frame, textvariable=self.exp_day_var, width=4).pack(side=tk.LEFT)
        ttk.Label(exp_date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(exp_date_frame, textvariable=self.exp_month_var, width=4).pack(side=tk.LEFT)
        ttk.Label(exp_date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(exp_date_frame, textvariable=self.exp_year_var, width=4).pack(side=tk.LEFT)
        
        ttk.Label(exp_date_frame, text="Format: DD-MM-YY", foreground="gray").pack(side=tk.LEFT, padx=10)
        
        # Tombol untuk simpan data
        button_frame = ttk.Frame(form_frame)
        button_frame.pack(fill=tk.X, pady=15)
        
        ttk.Button(
            button_frame, 
            text="Simpan Barang", 
            command=self.save_item,
            style="Accent.TButton"
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame, 
            text="Reset Form", 
            command=self.reset_form
        ).pack(side=tk.RIGHT, padx=5)
    

    def load_data(self):
        """Memuat data dari database MySQL ke treeview"""
        # Hapus semua data di treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            cursor.execute("SELECT nama, harga, jumlah, tanggal_kadaluarsa, tanggal_masuk FROM stok_barang ORDER BY tanggal_masuk DESC")
            rows = cursor.fetchall()
            
            for row in rows:
                # Format tanggal untuk tampilan
                exp_date_display = self.date_to_display_format(str(row[3]))
                entry_date_display = self.date_to_display_format(str(row[4]))
                
                # Format harga dengan pemisah ribuan
                harga_display = f"{row[1]:,.0f}"
                
                # Tambahkan ke treeview
                self.tree.insert("", tk.END, values=(
                    row[0],
                    harga_display,
                    row[2],
                    exp_date_display,
                    entry_date_display
                ))
            
            cursor.close()
            connection.close()
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat data: {str(e)}")

    def edit_item(self):
        """Fungsi untuk mengedit barang yang dipilih"""
        if not self.selected_item_id:
            messagebox.showinfo("Info", "Silakan pilih barang yang ingin diedit")
            return
        
        # Ambil data item yang dipilih
        item_values = self.tree.item(self.selected_item_id, "values")
        
        if len(item_values) < 5:
            messagebox.showerror("Error", "Data item tidak lengkap")
            return
        
        # Buat dialog untuk edit
        edit_window = tk.Toplevel(self.root)
        edit_window.title("Edit Barang")
        edit_window.geometry("500x350")
        edit_window.transient(self.root)  # Membuat window modal
        edit_window.grab_set()  # Fokus pada window ini
        
        # Form untuk edit
        form_frame = ttk.Frame(edit_window, padding=15)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Nama barang
        nama_frame = ttk.Frame(form_frame)
        nama_frame.pack(fill=tk.X, pady=5)
        ttk.Label(nama_frame, text="Nama Barang:", width=15).pack(side=tk.LEFT)
        nama_edit = tk.StringVar(value=item_values[0])
        nama_entry = ttk.Entry(nama_frame, textvariable=nama_edit, width=40)
        nama_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Harga
        harga_frame = ttk.Frame(form_frame)
        harga_frame.pack(fill=tk.X, pady=5)
        ttk.Label(harga_frame, text="Harga (Rp):", width=15).pack(side=tk.LEFT)
        
        # Hapus pemformatan harga
        try:
            harga_value = float(item_values[1].replace(",", ""))
        except ValueError:
            harga_value = 0
            
        harga_edit = tk.StringVar(value=str(harga_value))
        ttk.Entry(harga_frame, textvariable=harga_edit, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Jumlah
        jumlah_frame = ttk.Frame(form_frame)
        jumlah_frame.pack(fill=tk.X, pady=5)
        ttk.Label(jumlah_frame, text="Jumlah:", width=15).pack(side=tk.LEFT)
        jumlah_edit = tk.StringVar(value=item_values[2])
        ttk.Entry(jumlah_frame, textvariable=jumlah_edit, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Tanggal Kadaluarsa
        kadaluarsa_frame = ttk.Frame(form_frame)
        kadaluarsa_frame.pack(fill=tk.X, pady=5)
        ttk.Label(kadaluarsa_frame, text="Tanggal Kadaluarsa:", width=15).pack(side=tk.LEFT)
        
        # Konversi format tanggal tampilan DD-MM-YY ke DD, MM, YY untuk input
        try:
            exp_date_parts = item_values[3].split('-')
            exp_day = exp_date_parts[0]
            exp_month = exp_date_parts[1]
            exp_year = exp_date_parts[2]
        except (ValueError, IndexError):
            exp_day, exp_month, exp_year = "01", "01", "25"
        
        # Input untuk tanggal kadaluarsa (DD-MM-YYYY)
        exp_date_frame = ttk.Frame(kadaluarsa_frame)
        exp_date_frame.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        exp_day_edit = tk.StringVar(value=exp_day)
        exp_month_edit = tk.StringVar(value=exp_month)
        exp_year_edit = tk.StringVar(value=exp_year)
        
        ttk.Entry(exp_date_frame, textvariable=exp_day_edit, width=4).pack(side=tk.LEFT)
        ttk.Label(exp_date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(exp_date_frame, textvariable=exp_month_edit, width=4).pack(side=tk.LEFT)
        ttk.Label(exp_date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(exp_date_frame, textvariable=exp_year_edit, width=4).pack(side=tk.LEFT)
        
        ttk.Label(exp_date_frame, text="Format: DD-MM-YYYY", foreground="gray").pack(side=tk.LEFT, padx=10)
        
        # Fungsi untuk menyimpan hasil edit
        def save_edit():
            """Fungsi untuk menyimpan hasil edit"""
            try:
                # Validasi input
                if not nama_edit.get() or not harga_edit.get() or not jumlah_edit.get():
                    messagebox.showerror("Error", "Semua field harus diisi!", parent=edit_window)
                    return
                
                new_harga = float(harga_edit.get())
                new_jumlah = int(jumlah_edit.get())
                
                if new_harga <= 0 or new_jumlah <= 0:
                    messagebox.showerror("Error", "Harga dan Jumlah harus lebih dari 0!", parent=edit_window)
                    return
                
                # Validasi format tanggal kadaluarsa
                try:
                    day = int(exp_day_edit.get())
                    month = int(exp_month_edit.get())
                    year = exp_year_edit.get()
                    
                    # Konversi ke format internal YYYY-MM-DD
                    new_exp_date = self.date_to_internal_format(day, month, year)
                    
                    # Validasi tanggal kadaluarsa
                    datetime.strptime(new_exp_date, "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror("Error", "Format tanggal kadaluarsa tidak valid! Gunakan format DD-MM-YYYY", parent=edit_window)
                    return
                
                # Update data di database MySQL
                connection = mysql.connector.connect(**self.db_config)
                cursor = connection.cursor()

                # Nama lama untuk identifikasi record yang akan diupdate
                old_nama = item_values[0]

                query = """UPDATE stok_barang 
                        SET nama = %s, harga = %s, jumlah = %s, tanggal_kadaluarsa = %s 
                        WHERE nama = %s"""
                cursor.execute(query, (nama_edit.get(), new_harga, new_jumlah, new_exp_date, old_nama))

                if cursor.rowcount > 0:
                    connection.commit()
                    edit_window.destroy()
                    self.load_data()
                    messagebox.showinfo("Sukses", f"Barang {nama_edit.get()} berhasil diupdate!")
                else:
                    messagebox.showerror("Error", "Gagal mengupdate data. Item tidak ditemukan.", parent=edit_window)

                cursor.close()
                connection.close()
                        
            except ValueError:
                messagebox.showerror("Error", "Harga harus berupa angka dan Jumlah harus berupa bilangan bulat!", parent=edit_window)
            except Error as e:
                messagebox.showerror("Database Error", f"Terjadi kesalahan database: {str(e)}", parent=edit_window)
            except Exception as e:
                messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}", parent=edit_window)
        
        # Tombol untuk simpan perubahan dan batal
        button_frame = ttk.Frame(form_frame)
        button_frame.pack(fill=tk.X, pady=15)
        
        ttk.Button(
            button_frame, 
            text="Simpan Perubahan", 
            command=save_edit,
            style="Accent.TButton"
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame, 
            text="Batal", 
            command=edit_window.destroy
        ).pack(side=tk.RIGHT, padx=5)
        
    def delete_item(self):
        """Fungsi untuk menghapus barang yang dipilih"""
        if not self.selected_item_id:
            messagebox.showinfo("Info", "Silakan pilih barang yang ingin dihapus")
            return
        
        # Ambil data item yang dipilih
        item_values = self.tree.item(self.selected_item_id, "values")
        
        if len(item_values) < 5:
            messagebox.showerror("Error", "Data item tidak lengkap")
            return
        
        # Konfirmasi penghapusan
        confirm = messagebox.askyesno(
            "Konfirmasi Hapus", 
            f"Anda yakin ingin menghapus barang '{item_values[0]}'?"
        )
        
        if confirm:
            try:
                connection = mysql.connector.connect(**self.db_config)
                cursor = connection.cursor()
                
                # Hapus berdasarkan nama barang
                query = "DELETE FROM stok_barang WHERE nama = %s"
                cursor.execute(query, (item_values[0],))
                
                if cursor.rowcount > 0:
                    connection.commit()
                    self.load_data()
                    messagebox.showinfo("Sukses", f"Barang {item_values[0]} berhasil dihapus!")
                else:
                    messagebox.showerror("Error", "Gagal menghapus data. Item tidak ditemukan.")
                
                cursor.close()
                connection.close()
                    
            except Exception as e:
                messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def sell_item(self):
        """Fungsi untuk mencatat penjualan barang"""
        if not self.selected_item_id:
            messagebox.showinfo("Info", "Silakan pilih barang yang ingin dijual")
            return
        
        # Ambil data item yang dipilih
        item_values = self.tree.item(self.selected_item_id, "values")
        
        if len(item_values) < 5:
            messagebox.showerror("Error", "Data item tidak lengkap")
            return
        
        # Dialog untuk input jumlah terjual
        jumlah_terjual = simpledialog.askinteger(
            "Penjualan", 
            f"Berapa unit '{item_values[0]}' yang terjual?\n\nStok tersedia: {item_values[2]} unit",
            minvalue=1,
            maxvalue=int(item_values[2])
        )
        
        if jumlah_terjual is None:
            return
        
        try:
            # Hitung sisa stok
            stok_lama = int(item_values[2])
            sisa_stok = stok_lama - jumlah_terjual
            
            # Hitung total harga penjualan
            harga_satuan = float(item_values[1].replace(",", ""))
            total_harga = harga_satuan * jumlah_terjual
            
            # Simpan ke database
            self.save_sale_to_db(item_values[0], harga_satuan, jumlah_terjual, total_harga)
            
            # Update stok di database.csv
            if sisa_stok > 0:
                self.update_stock(item_values, sisa_stok)
            else:
                # Hapus barang jika stok habis
                self.remove_item_from_database(item_values)
            
            self.load_data()
            messagebox.showinfo("Sukses", f"Penjualan berhasil dicatat!\n\nBarang: {item_values[0]}\nTerjual: {jumlah_terjual} unit\nTotal: Rp {total_harga:,.0f}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")
    
    def save_sale_to_db(self, nama_barang, harga_satuan, jumlah, total_harga):
        """Simpan data penjualan ke database"""
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = """INSERT INTO penjualan (nama_barang, harga_satuan, jumlah, total_harga, tanggal_penjualan) 
                    VALUES (%s, %s, %s, %s, %s)"""
            cursor.execute(query, (nama_barang, harga_satuan, jumlah, total_harga, datetime.now().strftime("%Y-%m-%d")))
            
            connection.commit()
            cursor.close()
            connection.close()
            
        except Error as e:
            raise Exception(f"Gagal menyimpan data penjualan: {str(e)}")

    def discard_item(self):
        """Fungsi untuk membuang barang kadaluarsa"""
        if not self.selected_item_id:
            messagebox.showinfo("Info", "Silakan pilih barang yang ingin dibuang")
            return
        
        # Ambil data item yang dipilih
        item_values = self.tree.item(self.selected_item_id, "values")
        
        if len(item_values) < 5:
            messagebox.showerror("Error", "Data item tidak lengkap")
            return
        
        # Konfirmasi pembuangan
        confirm = messagebox.askyesno(
            "Konfirmasi Buang", 
            f"Anda yakin ingin membuang barang '{item_values[0]}' karena kadaluarsa?\n\nBarang ini tidak akan dicatat sebagai penjualan."
        )
        
        if confirm:
            try:
                # Hapus barang dari database
                self.remove_item_from_database(item_values)
                self.load_data()
                messagebox.showinfo("Sukses", f"Barang '{item_values[0]}' berhasil dibuang!")
                
            except Exception as e:
                messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def on_item_select(self, event):
        """Fungsi yang dipanggil saat item dipilih di treeview"""
        selected_items = self.tree.selection()
        if selected_items:
            self.selected_item_id = selected_items[0]
        else:
            self.selected_item_id = None
    def setup_view_tab(self, parent):
        """Membuat antarmuka tab Atur & Lihat Stok"""
        control_frame = ttk.Frame(parent)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(
            control_frame, 
            text="Muat Ulang Data", 
            command=self.load_data
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            control_frame, 
            text="Edit Barang", 
            command=self.edit_item
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            control_frame, 
            text="Hapus Barang", 
            command=self.delete_item
        ).pack(side=tk.LEFT, padx=5)
        
        # Tombol baru untuk Terjual dan Buang
        ttk.Button(
            control_frame, 
            text="Terjual", 
            command=self.sell_item,
            style="Accent.TButton"
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            control_frame, 
            text="Buang (Kadaluarsa)", 
            command=self.discard_item
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            control_frame, 
            text="Ekspor Semua ke CSV", 
            command=lambda: self.export_to_csv()
        ).pack(side=tk.RIGHT, padx=5)
        
        # Tabel untuk menampilkan data
        table_frame = ttk.Frame(parent)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Scrollbar
        y_scrollbar = ttk.Scrollbar(table_frame)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Treeview untuk menampilkan data dalam bentuk tabel
        self.tree = ttk.Treeview(
            table_frame,
            columns=self.columns,
            show="headings",
            yscrollcommand=y_scrollbar.set
        )
        
        # Konfigurasi scrollbar
        y_scrollbar.config(command=self.tree.yview)
        
        # Menentukan heading kolom
        for col in self.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor=tk.CENTER)
        
        # Bind untuk seleksi baris
        self.tree.bind("<<TreeviewSelect>>", self.on_item_select)
        
        self.tree.pack(fill=tk.BOTH, expand=True)
    
    def filter_expired(self):
        """Memfilter barang yang akan kadaluarsa"""
        # Hapus semua data di filter tree
        for item in self.filter_tree.get_children():
            self.filter_tree.delete(item)
        
        try:
            # Ambil tanggal filter
            day = int(self.filter_day_var.get())
            month = int(self.filter_month_var.get())
            year = self.filter_year_var.get()
            
            # Konversi ke format internal YYYY-MM-DD
            filter_date = self.date_to_internal_format(day, month, year)
            
            # Validasi tanggal
            filter_date_obj = datetime.strptime(filter_date, "%Y-%m-%d")
            
            # Baca data dari database
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = "SELECT nama, harga, jumlah, tanggal_kadaluarsa, tanggal_masuk FROM stok_barang WHERE tanggal_kadaluarsa <= %s ORDER BY tanggal_kadaluarsa ASC"
            cursor.execute(query, (filter_date,))
            rows = cursor.fetchall()
            
            cursor.close()
            connection.close()
            
            self.filtered_data = []
            
            for row in rows:
                # Konversi ke format yang sama dengan CSV untuk kompatibilitas
                csv_row = [row[0], str(row[1]), str(row[2]), str(row[3]), str(row[4])]
                self.filtered_data.append(csv_row)
                
                # Format tanggal untuk tampilan
                exp_date_display = self.date_to_display_format(str(row[3]))
                entry_date_display = self.date_to_display_format(str(row[4]))
                
                # Format harga dengan pemisah ribuan
                harga_display = f"{row[1]:,.0f}"
                
                # Tambahkan ke filter tree dengan warna berdasarkan kecepatan kadaluarsa
                exp_date_obj = datetime.strptime(str(row[3]), "%Y-%m-%d")
                days_to_expire = (exp_date_obj - datetime.now()).days
                tag = ""
                
                if days_to_expire < 0:
                    tag = "expired"
                elif days_to_expire < 7:
                    tag = "critical"
                elif days_to_expire < 30:
                    tag = "warning"
                
                item_id = self.filter_tree.insert("", tk.END, values=(
                    row[0],
                    harga_display,
                    row[2],
                    exp_date_display,
                    entry_date_display
                ), tags=(tag,))
            
            # Konfigurasi tag untuk warna baris
            self.filter_tree.tag_configure("expired", background="#ffcccc")  # Merah muda untuk barang kadaluarsa
            self.filter_tree.tag_configure("critical", background="#ffffcc")  # Kuning untuk barang hampir kadaluarsa
            self.filter_tree.tag_configure("warning", background="#e6f3ff")  # Biru muda untuk peringatan
            
            # Tampilkan hasil filter
            messagebox.showinfo("Filter", f"Ditemukan {len(self.filtered_data)} barang yang akan kadaluarsa sebelum {day:02d}-{month:02d}-{year}")
            
        except ValueError as e:
            messagebox.showerror("Error", f"Format tanggal tidak valid: {str(e)}")
        except Error as e:
            messagebox.showerror("Database Error", f"Terjadi kesalahan: {str(e)}")

    def setup_filter_tab(self, parent):
        """Membuat antarmuka tab Filter Kadaluarsa"""
        filter_frame = ttk.LabelFrame(parent, text="Filter Barang Kadaluarsa", padding=15)
        filter_frame.pack(fill=tk.X, padx=5, pady=10)
        
        # Input tanggal filter
        date_frame = ttk.Frame(filter_frame)
        date_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(date_frame, text="Tampilkan barang yang kadaluarsa sebelum:").pack(side=tk.LEFT, padx=5)
        
        self.filter_day_var = tk.StringVar()
        self.filter_month_var = tk.StringVar()
        self.filter_year_var = tk.StringVar()
        
        # Set tanggal default ke hari ini
        today = date.today()
        self.filter_day_var.set(str(today.day).zfill(2))
        self.filter_month_var.set(str(today.month).zfill(2))
        self.filter_year_var.set(str(today.year)[2:])  # Hanya 2 digit terakhir tahun
        
        ttk.Entry(date_frame, textvariable=self.filter_day_var, width=4).pack(side=tk.LEFT)
        ttk.Label(date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(date_frame, textvariable=self.filter_month_var, width=4).pack(side=tk.LEFT)
        ttk.Label(date_frame, text="-").pack(side=tk.LEFT)
        ttk.Entry(date_frame, textvariable=self.filter_year_var, width=4).pack(side=tk.LEFT)
        
        ttk.Label(date_frame, text="Format: DD-MM-YYYY", foreground="gray").pack(side=tk.LEFT, padx=10)
        
        # Tombol untuk menjalankan filter
        button_frame = ttk.Frame(filter_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(
            button_frame, 
            text="Jalankan Filter", 
            command=self.filter_expired
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame, 
            text="Ekspor Hasil Filter ke CSV", 
            command=lambda: self.export_to_csv(filtered=True)
        ).pack(side=tk.RIGHT, padx=5)
        
        # Tabel untuk menampilkan hasil filter
        table_frame = ttk.Frame(parent)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Scrollbar
        y_scrollbar = ttk.Scrollbar(table_frame)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Treeview untuk menampilkan data dalam bentuk tabel
        self.filter_tree = ttk.Treeview(
            table_frame,
            columns=self.columns,
            show="headings",
            yscrollcommand=y_scrollbar.set
        )
        
        # Konfigurasi scrollbar
        y_scrollbar.config(command=self.filter_tree.yview)
        
        # Menentukan heading kolom
        for col in self.columns:
            self.filter_tree.heading(col, text=col)
            self.filter_tree.column(col, width=100, anchor=tk.CENTER)
        
        self.filter_tree.pack(fill=tk.BOTH, expand=True)

    def reset_kulakan_form(self):
        """Membersihkan form input kulakan"""
        self.toko_var.set("")
        self.kulakan_barang_var.set("")
        self.kulakan_harga_var.set("")
        self.catatan_var.set("")

    def save_kulakan(self):
        """Menyimpan data kulakan ke database MySQL"""
        # Mengambil nilai dari form
        toko = self.toko_var.get().strip()
        barang = self.kulakan_barang_var.get().strip()
        harga = self.kulakan_harga_var.get().strip()
        catatan = self.catatan_var.get().strip()
        
        # Validasi input
        if not toko or not barang or not harga:
            messagebox.showerror("Error", "Nama Toko, Barang, dan Harga harus diisi!")
            return
        
        try:
            harga = float(harga)
            
            if harga <= 0:
                messagebox.showerror("Error", "Harga harus lebih dari 0!")
                return
                
        except ValueError:
            messagebox.showerror("Error", "Harga harus berupa angka!")
            return
        
        # Menggunakan tanggal hari ini
        today = datetime.now().strftime("%Y-%m-%d")
        
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = """INSERT INTO kulakan (nama_toko, nama_barang, harga, tanggal, catatan) 
                    VALUES (%s, %s, %s, %s, %s)"""
            cursor.execute(query, (toko, barang, harga, today, catatan))
            
            connection.commit()
            cursor.close()
            connection.close()
            
            # Reset form dan tampilkan pesan sukses
            self.reset_kulakan_form()
            self.load_store_list()  # Refresh daftar toko
            messagebox.showinfo("Sukses", f"Data kulakan untuk {barang} dari toko {toko} berhasil ditambahkan!")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal menyimpan data kulakan: {str(e)}")
    
    def search_best_price(self):
        """Mencari dan membandingkan harga kulakan terbaik menggunakan algoritma optimasi"""
        search_term = self.search_var.get().strip().lower()
        
        if not search_term:
            messagebox.showinfo("Info", "Silakan masukkan nama barang yang ingin dicari")
            return
        
        try:
            # Hapus data di treeview hasil pencarian
            for item in self.kulakan_tree.get_children():
                self.kulakan_tree.delete(item)
            
            # Baca data kulakan dari database
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = "SELECT nama_toko, nama_barang, harga FROM kulakan WHERE LOWER(nama_barang) LIKE %s ORDER BY harga ASC"
            cursor.execute(query, (f"%{search_term}%",))
            rows = cursor.fetchall()
            
            cursor.close()
            connection.close()
            
            if not rows:
                messagebox.showinfo("Info", f"Tidak ditemukan data kulakan untuk barang '{search_term}'")
                return
            
            # Tampilkan di treeview dengan warna pada harga terendah
            first_item = True
            for row in rows:
                # Format harga
                harga_display = f"{row[2]:,.0f}"
                
                # Tambahkan ke treeview dengan tag untuk warna berdasarkan urutan
                tag = "best_price" if first_item else ""
                
                self.kulakan_tree.insert("", tk.END, values=(
                    row[0],  # Nama Toko
                    row[1],  # Nama Barang
                    harga_display  # Harga
                ), tags=(tag,))
                
                first_item = False
            
            # Konfigurasi tag untuk warna baris
            self.kulakan_tree.tag_configure("best_price", background="#e8f5e9")  # Hijau muda untuk harga terendah
            
            messagebox.showinfo("Pencarian", f"Ditemukan {len(rows)} hasil pencarian untuk '{search_term}'.\nUntuk harga terbaik, cek baris berwarna hijau.")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Terjadi kesalahan saat mencari data: {str(e)}")

    def show_store_products(self):
        """Display products from the selected store"""
        selected_store = self.store_select_var.get()
        
        if not selected_store:
            messagebox.showinfo("Info", "Silakan pilih toko terlebih dahulu")
            return
        
        try:
            # Clear existing data
            for item in self.store_product_tree.get_children():
                self.store_product_tree.delete(item)
            
            # Read data from database
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            query = "SELECT nama_barang, harga, catatan FROM kulakan WHERE nama_toko = %s"
            cursor.execute(query, (selected_store,))
            rows = cursor.fetchall()
            
            cursor.close()
            connection.close()
            
            if not rows:
                messagebox.showinfo("Info", f"Tidak ada produk yang tersedia dari toko {selected_store}")
                return
            
            # Display products
            for row in rows:
                # Format harga
                harga_display = f"{row[1]:,.0f}"
                
                self.store_product_tree.insert("", tk.END, values=(
                    row[0],       # Nama Barang
                    harga_display,    # Harga
                    row[2]        # Catatan
                ))
                
            messagebox.showinfo("Info", f"Menampilkan {len(rows)} produk dari toko {selected_store}")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal menampilkan produk toko: {str(e)}")
            
    def load_store_list(self):
        """Load list of stores for the combobox"""
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            cursor.execute("SELECT DISTINCT nama_toko FROM kulakan ORDER BY nama_toko")
            stores = [row[0] for row in cursor.fetchall()]
            
            cursor.close()
            connection.close()
            
            # Update combobox
            self.store_combo['values'] = stores
            
            # Select first store if available
            if stores:
                self.store_select_var.set(stores[0])
                
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat daftar toko: {str(e)}")

    def setup_kulakan_tab(self, parent):
        """Membuat antarmuka tab Smart Kulakan"""
        # Frame utama dengan scrollbar
        main_frame = ttk.Frame(parent)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Canvas untuk scrolling
        canvas = tk.Canvas(main_frame)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Frame untuk input data kulakan
        input_frame = ttk.LabelFrame(scrollable_frame, text="Input Data Kulakan", padding=15)
        input_frame.pack(fill=tk.X, padx=5, pady=10)
        
        # Nama Toko
        toko_frame = ttk.Frame(input_frame)
        toko_frame.pack(fill=tk.X, pady=5)
        ttk.Label(toko_frame, text="Nama Toko:", width=15).pack(side=tk.LEFT)
        self.toko_var = tk.StringVar()
        ttk.Entry(toko_frame, textvariable=self.toko_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Nama Barang
        barang_frame = ttk.Frame(input_frame)
        barang_frame.pack(fill=tk.X, pady=5)
        ttk.Label(barang_frame, text="Nama Barang:", width=15).pack(side=tk.LEFT)
        self.kulakan_barang_var = tk.StringVar()
        ttk.Entry(barang_frame, textvariable=self.kulakan_barang_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Harga kulakan
        harga_frame = ttk.Frame(input_frame)
        harga_frame.pack(fill=tk.X, pady=5)
        ttk.Label(harga_frame, text="Harga (Rp):", width=15).pack(side=tk.LEFT)
        self.kulakan_harga_var = tk.StringVar()
        ttk.Entry(harga_frame, textvariable=self.kulakan_harga_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Catatan
        catatan_frame = ttk.Frame(input_frame)
        catatan_frame.pack(fill=tk.X, pady=5)
        ttk.Label(catatan_frame, text="Catatan:", width=15).pack(side=tk.LEFT)
        self.catatan_var = tk.StringVar()
        ttk.Entry(catatan_frame, textvariable=self.catatan_var, width=40).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Tombol untuk simpan data kulakan
        button_frame = ttk.Frame(input_frame)
        button_frame.pack(fill=tk.X, pady=15)
        
        ttk.Button(
            button_frame, 
            text="Simpan Data Kulakan", 
            command=self.save_kulakan,
            style="Accent.TButton"
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame, 
            text="Reset Form", 
            command=self.reset_kulakan_form
        ).pack(side=tk.RIGHT, padx=5)
        
        # Frame untuk pencarian dan perbandingan
        search_frame = ttk.LabelFrame(scrollable_frame, text="Cari & Bandingkan Harga Kulakan", padding=15)
        search_frame.pack(fill=tk.X, padx=5, pady=10)
        
        # Input pencarian
        search_box_frame = ttk.Frame(search_frame)
        search_box_frame.pack(fill=tk.X, pady=5)
        ttk.Label(search_box_frame, text="Nama Barang:").pack(side=tk.LEFT, padx=5)
        
        self.search_var = tk.StringVar()
        ttk.Entry(search_box_frame, textvariable=self.search_var, width=30).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        ttk.Button(
            search_box_frame, 
            text="Cari & Bandingkan", 
            command=self.search_best_price
        ).pack(side=tk.LEFT, padx=5)
        
        # Hasil pencarian
        result_frame = ttk.Frame(scrollable_frame)
        result_frame.pack(fill=tk.X, expand=True, padx=5, pady=5)
        
        # Treeview untuk hasil pencarian (tanpa scrollbar terpisah)
        self.kulakan_tree = ttk.Treeview(
            result_frame,
            columns=["Nama Toko", "Nama Barang", "Harga"],
            show="headings",
            height=6  # Batasi tinggi treeview
        )
        
        # Menentukan heading kolom (tanpa Tanggal dan Catatan)
        for col in ["Nama Toko", "Nama Barang", "Harga"]:
            self.kulakan_tree.heading(col, text=col)
            if col == "Nama Barang":
                self.kulakan_tree.column(col, width=200, anchor=tk.CENTER)
            else:
                self.kulakan_tree.column(col, width=150, anchor=tk.CENTER)
        
        self.kulakan_tree.pack(fill=tk.X, expand=True, pady=5)
        
        # Frame baru untuk menampilkan produk berdasarkan toko
        store_frame = ttk.LabelFrame(scrollable_frame, text="Produk Berdasarkan Toko", padding=15)
        store_frame.pack(fill=tk.X, padx=5, pady=10)
        
        # Combo box untuk pilih toko
        store_select_frame = ttk.Frame(store_frame)
        store_select_frame.pack(fill=tk.X, pady=5)
        ttk.Label(store_select_frame, text="Pilih Toko:").pack(side=tk.LEFT, padx=5)
        
        self.store_select_var = tk.StringVar()
        self.store_combo = ttk.Combobox(store_select_frame, textvariable=self.store_select_var, state="readonly")
        self.store_combo.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        ttk.Button(
            store_select_frame, 
            text="Tampilkan Produk", 
            command=self.show_store_products
        ).pack(side=tk.LEFT, padx=5)
        
        # Treeview untuk produk toko
        store_product_frame = ttk.Frame(scrollable_frame)
        store_product_frame.pack(fill=tk.X, expand=True, padx=5, pady=5)
        
        self.store_product_tree = ttk.Treeview(
            store_product_frame,
            columns=["Nama Barang", "Harga", "Catatan"],
            show="headings",
            height=8  # Batasi tinggi treeview
        )
        
        # Menentukan heading kolom
        self.store_product_tree.heading("Nama Barang", text="Nama Barang")
        self.store_product_tree.column("Nama Barang", width=200, anchor=tk.W)
        
        self.store_product_tree.heading("Harga", text="Harga")
        self.store_product_tree.column("Harga", width=100, anchor=tk.CENTER)
        
        self.store_product_tree.heading("Catatan", text="Catatan")
        self.store_product_tree.column("Catatan", width=250, anchor=tk.W)
        
        self.store_product_tree.pack(fill=tk.X, expand=True, pady=5)
        
        # Load daftar toko saat pertama kali
        self.load_store_list()
        
    def setup_sales_tab(self, parent):
        """Setup tab untuk penjualan"""
        pass  # Tab ini sudah dihapus

    def load_sales_report(self):
        """Load data laporan penjualan"""
        # Hapus data lama
        for item in self.sales_tree.get_children():
            self.sales_tree.delete(item)
        
        total_revenue = 0
        total_items = 0
        
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            cursor.execute("SELECT nama_barang, harga_satuan, jumlah, total_harga, tanggal_penjualan FROM penjualan ORDER BY tanggal_penjualan DESC")
            rows = cursor.fetchall()
            
            for row in rows:
                # Format data untuk tampilan
                harga_satuan = float(row[1])
                jumlah = int(row[2])
                total_harga = float(row[3])
                tanggal = self.date_to_display_format(str(row[4]))
                
                # Tambah ke tree
                self.sales_tree.insert("", tk.END, values=(
                    row[0],
                    f"Rp {harga_satuan:,.0f}",
                    jumlah,
                    f"Rp {total_harga:,.0f}",
                    tanggal
                ))
                
                # Hitung total
                total_revenue += total_harga
                total_items += jumlah
            
            cursor.close()
            connection.close()
            
            # Update label total
            self.total_sales_label.config(text=f"Total Penjualan: Rp {total_revenue:,.0f}")
            self.total_items_label.config(text=f"Total Barang Terjual: {total_items} unit")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat laporan: {str(e)}")

    def export_sales_report(self):
        """Ekspor laporan penjualan ke CSV"""
        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title="Simpan Laporan Penjualan"
            )
            
            if not file_path:
                return
            
            # Export dari database ke CSV
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            cursor.execute("SELECT nama_barang, harga_satuan, jumlah, total_harga, tanggal_penjualan FROM penjualan ORDER BY tanggal_penjualan DESC")
            rows = cursor.fetchall()
            
            with open(file_path, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Nama Barang", "Harga Satuan", "Jumlah", "Total Harga", "Tanggal Penjualan"])
                writer.writerows(rows)
            
            cursor.close()
            connection.close()
            
            messagebox.showinfo("Sukses", f"Laporan berhasil diekspor ke {file_path}")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal mengekspor laporan: {str(e)}")
        
    def date_to_internal_format(self, day, month, year):
        
        if len(str(year)) == 2:
            current_century = datetime.now().year // 100 * 100
            full_year = current_century + int(year)
        else:
            full_year = int(year)
            
        return f"{full_year:04d}-{int(month):02d}-{int(day):02d}"

    def date_to_display_format(self, date_str):
        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            return date_obj.strftime("%d-%m-%Y")
        except ValueError:
            return date_str

    def update_stock(self, item_values, new_stock):
        """Update stok barang di database"""
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            # Update berdasarkan nama barang (asumsi nama unik)
            query = "UPDATE stok_barang SET jumlah = %s WHERE nama = %s"
            cursor.execute(query, (new_stock, item_values[0]))
            
            connection.commit()
            cursor.close()
            connection.close()
            
        except Error as e:
            raise Exception(f"Gagal mengupdate stok: {str(e)}")

    def remove_item_from_database(self, item_values):
        """Hapus item dari database"""
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            # Hapus berdasarkan nama barang (asumsi nama unik)
            query = "DELETE FROM stok_barang WHERE nama = %s"
            cursor.execute(query, (item_values[0],))
            
            connection.commit()
            cursor.close()
            connection.close()
            
        except Error as e:
            raise Exception(f"Gagal menghapus item: {str(e)}")
    
    def export_to_csv(self, filtered=False):
        """Ekspor data ke file CSV"""
        try:
            # Tentukan file tujuan
            file_path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title="Simpan Data Sebagai CSV"
            )
            
            if not file_path:
                return
            
            with open(file_path, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(self.columns)
                
                if filtered and self.filtered_data:
                    # Ekspor data yang sudah difilter
                    writer.writerows(self.filtered_data)
                else:
                    # Ekspor semua data dari database
                    connection = mysql.connector.connect(**self.db_config)
                    cursor = connection.cursor()
                    
                    cursor.execute("SELECT nama, harga, jumlah, tanggal_kadaluarsa, tanggal_masuk FROM stok_barang ORDER BY tanggal_masuk DESC")
                    rows = cursor.fetchall()
                    
                    writer.writerows(rows)
                    
                    cursor.close()
                    connection.close()
            
            messagebox.showinfo("Sukses", f"Data berhasil diekspor ke {file_path}")
            
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal mengekspor data: {str(e)}")
    
def setup_styles():
    """Mengatur style untuk tampilan yang lebih menarik"""
    style = ttk.Style()
    
    # Menggunakan tema 'clam' sebagai dasar
    style.theme_use('clam')
    
    # Mengatur warna dan padding
    style.configure('TFrame', background='#f0f0f0')
    style.configure('TLabelframe', background='#f0f0f0')
    style.configure('TLabelframe.Label', font=('Arial', 10, 'bold'))
    
    # Button style
    style.configure('TButton', font=('Arial', 10), background='#e1e1e1')
    style.map('TButton',
        background=[('active', '#d0d0d0')],
        relief=[('pressed', 'sunken'), ('!pressed', 'raised')])
    
    # Accent button untuk tombol penting
    style.configure('Accent.TButton', 
                   font=('Arial', 10, 'bold'), 
                   background='#4CAF50', 
                   foreground='white')
    style.map('Accent.TButton',
        background=[('active', '#3e8e41')],
        foreground=[('active', 'white')])
    
    # Label style
    style.configure('TLabel', font=('Arial', 10), background='#f0f0f0')
    
    # Entry style
    style.configure('TEntry', font=('Arial', 10))
    
    # Treeview style
    style.configure('Treeview', 
                    font=('Arial', 10),
                    rowheight=25,
                    background='#ffffff',
                    fieldbackground='#ffffff')
    style.configure('Treeview.Heading', font=('Arial', 10, 'bold'))
    
    # Ubah warna seleksi
    style.map('Treeview',
        background=[('selected', '#4CAF50')],
        foreground=[('selected', 'white')])
    
    # Style untuk notebook (tab)
    style.configure('TNotebook', background='#f0f0f0')
    style.configure('TNotebook.Tab', 
                   font=('Arial', 10),
                   padding=[10, 5],
                   background='#e1e1e1')
    style.map('TNotebook.Tab',
        background=[('selected', '#4CAF50'), ('active', '#d0d0d0')],
        foreground=[('selected', 'white')])

    def save_edit():
        """Fungsi untuk menyimpan hasil edit"""
        try:
            # Validasi input
            if not nama_edit.get() or not harga_edit.get() or not jumlah_edit.get():
                messagebox.showerror("Error", "Semua field harus diisi!", parent=edit_window)
                return
            
            new_harga = float(harga_edit.get())
            new_jumlah = int(jumlah_edit.get())
            
            if new_harga <= 0 or new_jumlah <= 0:
                messagebox.showerror("Error", "Harga dan Jumlah harus lebih dari 0!", parent=edit_window)
                return
            
            # Validasi format tanggal kadaluarsa
            try:
                day = int(exp_day_edit.get())
                month = int(exp_month_edit.get())
                year = exp_year_edit.get()
                
                # Konversi ke format internal YYYY-MM-DD
                new_exp_date = self.date_to_internal_format(day, month, year)
                
                # Validasi tanggal kadaluarsa
                datetime.strptime(new_exp_date, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Format tanggal kadaluarsa tidak valid! Gunakan format DD-MM-YYYY", parent=edit_window)
                return
            
            # Update data di database MySQL
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()

            # Nama lama untuk identifikasi record yang akan diupdate
            old_nama = item_values[0]

            query = """UPDATE stok_barang 
                    SET nama = %s, harga = %s, jumlah = %s, tanggal_kadaluarsa = %s 
                    WHERE nama = %s"""
            cursor.execute(query, (nama_edit.get(), new_harga, new_jumlah, new_exp_date, old_nama))

            if cursor.rowcount > 0:
                connection.commit()
                edit_window.destroy()
                self.load_data()
                messagebox.showinfo("Sukses", f"Barang {nama_edit.get()} berhasil diupdate!")
            else:
                messagebox.showerror("Error", "Gagal mengupdate data. Item tidak ditemukan.", parent=edit_window)

            cursor.close()
            connection.close()
                    
        except ValueError:
            messagebox.showerror("Error", "Harga harus berupa angka dan Jumlah harus berupa bilangan bulat!", parent=edit_window)
        except Error as e:
            messagebox.showerror("Database Error", f"Terjadi kesalahan database: {str(e)}", parent=edit_window)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}", parent=edit_window)

def main():
    root = tk.Tk()
    
    # Atur ikon aplikasi jika ada
    try:
        # Coba temukan ikon di folder yang sama dengan script
        script_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        icon_path = os.path.join(script_dir, "retail.ico")
        
        if os.path.exists(icon_path):
            root.iconbitmap(icon_path)
    except:
        pass  # Lanjutkan jika ikon tidak ditemukan
    
    # Atur style tema
    setup_styles()
    
    # Ciptakan instance aplikasi
    app = Retailese(root)
    
    # Jalankan aplikasi
    root.mainloop()

if __name__ == "__main__":
    main()

